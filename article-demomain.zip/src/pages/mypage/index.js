function MyPage() {
  return <div>my-page</div>;
}

export default MyPage;

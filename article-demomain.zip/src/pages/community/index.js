function Community() {
  return <div>community</div>;
}

export default Community;
